package com.remedio.app.product_app.ApiCalling

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object BuilderServices {

    private val client = OkHttpClient.Builder().build()

    private val retrofit = Retrofit.Builder().baseUrl("https://wtsacademy.dedicateddevelopers.us/api/")
        .addConverterFactory(GsonConverterFactory.create()).client(client).build()

    fun <T> createService(services: Class<T>):T{
        return retrofit.create(services)
    }

}