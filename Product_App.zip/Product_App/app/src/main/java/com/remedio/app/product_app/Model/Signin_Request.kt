package com.remedio.app.product_app.Model

data class Signin_Request(
    val email : String,
    val password : String
)
