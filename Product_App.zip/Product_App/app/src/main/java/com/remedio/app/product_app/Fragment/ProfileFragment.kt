package com.remedio.app.product_app.Fragment

import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.remedio.app.product_app.Model.Sign_in_list
import com.remedio.app.product_app.R
import com.remedio.app.product_app.databinding.FragmentProfileBinding
import com.squareup.picasso.Picasso


class ProfileFragment : Fragment() {
    private  var _binding: FragmentProfileBinding? = null
    private val binding  get() = _binding!!
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var signInList: Sign_in_list
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       _binding = FragmentProfileBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPreferences = requireActivity().getSharedPreferences("signInResponse", MODE_PRIVATE)
        val json = sharedPreferences.getString("user_data", "")
        signInList = Gson().fromJson(json,Sign_in_list::class.java)

        val data = signInList.data

        if (data!=null){
            binding.name.text = "${data.first_name} ${signInList.data?.last_name}"
            binding.email.text = data.email.toString()
            binding.Role.text = data.role_data?.role.toString()
            binding.createsdate.text = data.createdAt.toString()
            binding.UpdateDate.text = data.updatedAt.toString()
            if (data.profile_pic != null && data.profile_pic.isNotEmpty()){
               val profile =  "https://wtsacademy.dedicateddevelopers.us/uploads/user/profile_pic/${data.profile_pic}"
//                Log.d("res","${data.profile_pic}")
//                Picasso.get().load(data.profile_pic).into(binding.profileImage)
                Glide.with(requireContext()).load(profile).circleCrop().into(binding.profileImage)
            }
//            val datapic = data.profile_pic
//            Log.d("res","${data.profile_pic}")
            binding.scrolling.visibility = View.VISIBLE
            binding.progresbarprofile.visibility = View.GONE
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}