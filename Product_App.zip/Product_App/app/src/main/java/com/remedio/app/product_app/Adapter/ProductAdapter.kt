package com.remedio.app.product_app.Adapter

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.view.menu.ShowableListMenu
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textview.MaterialTextView
import com.google.gson.Gson
import com.remedio.app.product_app.Fragment.DetailsFragment
import com.remedio.app.product_app.Fragment.ProductFragment
import com.remedio.app.product_app.Interface.ProductActionListener
import com.remedio.app.product_app.Model.Datalist
import com.remedio.app.product_app.Model.Product_list
import com.remedio.app.product_app.R
import com.squareup.picasso.Picasso

class ProductAdapter(
    private val productList :ArrayList<Datalist>,
    private val listener: ProductActionListener,
    private val fragmentManager: FragmentManager
  ):
    RecyclerView.Adapter<ProductAdapter.MyViewHolder>() {

    private var filteredList: List<Datalist> = productList

    inner class MyViewHolder(view: View): RecyclerView.ViewHolder(view) {
        private val title: MaterialTextView = view.findViewById(R.id.txtProductTitle)
        private val description: MaterialTextView = view.findViewById(R.id.txtProductDescription)
        private val imageView : ImageView = view.findViewById(R.id.imagesshow)
        private val editButton : ImageButton = view.findViewById(R.id.edtProductBtn)
        private val deleteButton : ImageButton = view.findViewById(R.id.deleteBtn)
        private val itemclick: ConstraintLayout = view.findViewById(R.id.itemclick)

        fun bind(item: Datalist){
            title.text = item.title
            description.text = item.description
            if (!item.image.isNullOrEmpty()) {
                Picasso.get().load(item.image).placeholder(R.drawable.ic_launcher_foreground)
                    .error(R.drawable.ic_launcher_foreground).into(imageView)
            } else {
                Picasso.get().load(R.drawable.ic_launcher_foreground).into(imageView)
            }
            editButton.setOnClickListener { listener.onEditProduct(item) }
            deleteButton.setOnClickListener { listener.onDeleteProduct(item) }
            itemclick.setOnClickListener {
                val fragment = DetailsFragment().apply {
                    arguments = Bundle().apply {
                        putString("product_data", Gson().toJson(item))
                    }
                }
                fragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainerView, fragment)
                    .commit()
                Log.d("res","Show data")
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.product_card,parent,false))
    }

    override fun getItemCount(): Int {
        return filteredList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(filteredList[position])
    }

    fun filter(text: String) {
        filteredList = productList.filter {
            it.title?.startsWith(text, true) ?: false
        } as ArrayList<Datalist>
        notifyDataSetChanged()
    }
}