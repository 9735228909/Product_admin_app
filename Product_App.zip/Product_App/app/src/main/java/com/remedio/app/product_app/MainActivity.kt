package com.remedio.app.product_app

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.remedio.app.product_app.Model.Sign_in_list
import com.remedio.app.product_app.Ui.ProductActivity
import com.remedio.app.product_app.Ui.Sign_In
import com.remedio.app.product_app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var signInList: Sign_in_list

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val zoomInAnimation: Animation = AnimationUtils.loadAnimation(this, R.anim.zoom_in)
//        val zoomOutAnimation: Animation = AnimationUtils.loadAnimation(this, R.anim.zoom_out)

        // Start zoom-in animation
        binding.iamgeAniamation.startAnimation(zoomInAnimation)

        // Optionally, you can use a Handler to delay the zoom-out animation
        binding.iamgeAniamation.postDelayed({
            binding.iamgeAniamation.startAnimation(zoomInAnimation)
        }, zoomInAnimation.duration)

        sharedPreferences = getSharedPreferences("signInResponse", MODE_PRIVATE)

        Handler(Looper.getMainLooper()).postDelayed({
            if (isUserSignedIn()==true){
                val intent = Intent(this,ProductActivity::class.java)
                startActivity(intent)
                finish()
            }else{
                val intent = Intent(this,Sign_In::class.java)
                startActivity(intent)
                finish()
            }
        },2000)

    }

    private fun isUserSignedIn() : Boolean {
        val json = sharedPreferences.getString("user_data", null)
        return if (json != null) {
            signInList = Gson().fromJson(json, Sign_in_list::class.java)
            sharedPreferences.getBoolean("isLoggedIn", false)
        } else {
            false
        }
    }
}
