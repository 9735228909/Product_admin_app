package com.remedio.app.product_app.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.gson.Gson
import com.remedio.app.product_app.Model.Datalist
import com.remedio.app.product_app.R
import com.remedio.app.product_app.databinding.FragmentDetailsBinding
import com.remedio.app.product_app.databinding.FragmentHomeBinding
import com.squareup.picasso.Picasso
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone


class DetailsFragment : Fragment() {
    private var _binding : FragmentDetailsBinding?= null
    private val binding get() = _binding!!
    private var product: Datalist? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailsBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        retrieveData()
        setDataToViews()

    }


    private fun retrieveData() {
        val json = arguments?.getString("product_data")
        if (json.isNullOrEmpty()) {
            showError("Product data is missing or invalid.")
            return
        }

        product = try {
            Gson().fromJson(json, Datalist::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
        if (product == null) {
            showError("Failed to parse product data.")
        }
    }

    private fun setDataToViews() {
        product?.let {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

            binding.productId.text = "ID: ${it._id}"
            binding.productTitle.text = it.title
            binding.productDescription.text = it.description
            binding.productStatus.text = "Status: ${it.status}"
            Picasso.get().load(it.image).into(binding.productImage)

            val createdAtDate = dateFormat.format(parseDateString(it.createdAt))
            binding.productCreatedAt.text = "Created At: $createdAtDate"

            val updatedAtDate = dateFormat.format(parseDateString(it.updatedAt))
            binding.productUpdatedAt.text = "Updated At: $updatedAtDate"
        } ?: showError("Product data is not available.")
    }

    private fun parseDateString(dateString: String?): Date {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
        inputFormat.timeZone = TimeZone.getTimeZone("UTC")

        return try {
            inputFormat.parse(dateString) ?: Date()
        } catch (e: Exception) {
            e.printStackTrace()
            Date()
        }
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
