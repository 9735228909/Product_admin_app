package com.remedio.app.product_app.Ui

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.android.material.navigation.NavigationView
import com.google.gson.Gson
import com.remedio.app.product_app.Fragment.HomeFragment
import com.remedio.app.product_app.Fragment.ProductFragment
import com.remedio.app.product_app.Fragment.ProfileFragment
import com.remedio.app.product_app.Model.Sign_in_list
import com.remedio.app.product_app.R
import com.remedio.app.product_app.databinding.ActivityProductBinding

open class ProductActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProductBinding
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var signInList: Sign_in_list

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("signInResponse", MODE_PRIVATE)

        drawerLayout = binding.drawerlayout
        toggle = ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val navigationView = binding.navigationdrwwer
        navigationView.setNavigationItemSelectedListener {
            it.isChecked = true
            when (it.itemId) {
                R.id.nav_home -> {
                    replace(HomeFragment(), it.title.toString())
                    Toast.makeText(this, "Home Fragment", Toast.LENGTH_LONG).show()
                }
                R.id.nav_product_list -> {
                    replace(ProductFragment(), it.title.toString())
                    Toast.makeText(this, "Product List Fragment", Toast.LENGTH_LONG).show()
                }
                R.id.nav_profile -> {
                    replace(ProfileFragment(), it.title.toString())
                    Toast.makeText(this, "Profile Fragment", Toast.LENGTH_LONG).show()
                }
                R.id.nav_sign_out -> {
                    logoutUser()
                    Toast.makeText(this, "Log Out", Toast.LENGTH_LONG).show()
                }
            }
            true
        }

        val json =  sharedPreferences.getString("user_data", "")
        signInList = Gson().fromJson(json, Sign_in_list::class.java)

        val data = signInList.data

        if (data!=null){
           val name = "${data.first_name} ${signInList.data?.last_name}"
            val email = data.email
            val profileImageUrl =  "https://wtsacademy.dedicateddevelopers.us/uploads/user/profile_pic/${data.profile_pic}"
            updateHeader(name, email,profileImageUrl)
        }
    }

    fun updateHeader(name: String, email: String, profileImageUrl: String) {
        val navigationView = findViewById<NavigationView>(R.id.navigationdrwwer)
        navigationView?.let {
            val headerView = it.getHeaderView(0)
            headerView?.let { view ->
                val headerImageView = view.findViewById<ImageView>(R.id.headerImageView)
                val headerNameTextView = view.findViewById<TextView>(R.id.headerNameTextView)
                val headerEmailTextView = view.findViewById<TextView>(R.id.headerEmailTextView)

                headerNameTextView.text = name
                headerEmailTextView.text = email
                Glide.with(this).load(profileImageUrl).circleCrop().into(headerImageView)
            } ?: run {
                Log.e("ProductActivity", "Header view is null")
            }
        } ?: run {
            Log.e("ProductActivity", "Navigation view is null")
        }
    }


    private fun logoutUser() {
        val editor = sharedPreferences.edit()
        editor.putBoolean("isLoggedIn", false) // Set to false for logout
        editor.remove("user_data")
        editor.apply()
        val intent = Intent(this, Sign_In::class.java)
        startActivity(intent)
        finish()
    }

    private fun replace(fragment: Fragment, title: String) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainerView, fragment)
            .addToBackStack(null)
            .commit()
        drawerLayout.closeDrawers()
        setTitle(title)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (toggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }
}
