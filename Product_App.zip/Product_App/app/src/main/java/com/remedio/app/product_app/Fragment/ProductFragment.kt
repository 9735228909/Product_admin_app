package com.remedio.app.product_app.Fragment

import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.google.android.material.textfield.TextInputEditText
import com.google.gson.Gson
import com.remedio.app.product_app.Adapter.ProductAdapter
import com.remedio.app.product_app.ApiCalling.ApiInterface
import com.remedio.app.product_app.ApiCalling.BuilderServices
import com.remedio.app.product_app.FileUploadHelper
import com.remedio.app.product_app.FileUploadHelper.createMultipartFile
import com.remedio.app.product_app.Interface.ProductActionListener
import com.remedio.app.product_app.Model.CreateProductResponse
import com.remedio.app.product_app.Model.Datalist
import com.remedio.app.product_app.Model.Product_list
import com.remedio.app.product_app.Model.Sign_in_list
import com.remedio.app.product_app.R
import com.remedio.app.product_app.databinding.FragmentProductBinding
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File


class ProductFragment : Fragment(),ProductActionListener {

    private var _binding: FragmentProductBinding? = null
    private val binding get() = _binding!!
    private lateinit var productAdapter: ProductAdapter
    private  var productList = ArrayList<Datalist>()
    private lateinit var token:String
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var dialogImageView : ImageView
    private lateinit var progressBarDialog: ProgressBar
    private lateinit var file:File



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProductBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPreferences = requireContext().getSharedPreferences("signInResponse", MODE_PRIVATE)
        fetchTokenAndCallApi()


        binding.edtsearch.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {            }

            override fun afterTextChanged(s: Editable?) {
                productAdapter.filter(s.toString())
            }
        })

    }

    private fun fetchTokenAndCallApi(){
        token = loadTokenSharedPrefer()
        if (token.isNotEmpty()) {
            displayProductList(token)
        } else {
            Toast.makeText(requireContext(),"Failed to load token", Toast.LENGTH_LONG).show()
        }
    }

    private fun displayProductList(token: String) {
        binding.progressbar.visibility = View.VISIBLE
        val retrofit = BuilderServices.createService(ApiInterface::class.java)
        retrofit.getProductlist(token).enqueue(object : Callback<Product_list> {
            override fun onResponse(call: Call<Product_list>, response: Response<Product_list>) {
                binding.progressbar.visibility = View.GONE
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null) {
                        productList.clear()
                        productList.addAll(body.data)
                        productAdapter = ProductAdapter(productList, this@ProductFragment,requireFragmentManager())
                        binding.recyclerview.adapter = productAdapter
                    } else {
                        Toast.makeText(requireContext(),"Response body is null",Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(requireContext(),"API call not successful: ${response.errorBody()?.string()}",Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<Product_list>, t: Throwable) {
                binding.progressbar.visibility = View.GONE
                Toast.makeText(requireContext(), "Network Failure: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun loadTokenSharedPrefer(): String {
        val json =  sharedPreferences.getString("user_data","")
        return if (!json.isNullOrEmpty()){
            try {
                val signInList = Gson().fromJson(json, Sign_in_list::class.java)
                signInList.token
            }catch (e:Exception){
                Toast.makeText(requireContext(),"${e.message}",Toast.LENGTH_LONG).show()
                ""
            }
        }
        else{
            Toast.makeText(requireContext(),"No data SharedPreferences",Toast.LENGTH_LONG).show()
            ""
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onEditProduct(product: Datalist) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.createproduct,null)
        val dialog = AlertDialog.Builder(requireContext()).setView(dialogView).create()

        val titleEditText: TextInputEditText = dialogView.findViewById(R.id.etTitle)
        val descriptionEditText: TextInputEditText = dialogView.findViewById(R.id.etDescription)
        dialogImageView = dialogView.findViewById(R.id.ivProductImage)
        val heading : TextView = dialogView.findViewById(R.id.headingTV)
        val uploadImage : Button = dialogView.findViewById(R.id.btnUploadImage)
        val updateProductButton : Button = dialogView.findViewById(R.id.btnCreateProduct)
        progressBarDialog  = dialogView.findViewById(R.id.progressBarCreateProduct)
        uploadImage.setOnClickListener {
            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        titleEditText.setText(product.title)
        descriptionEditText.setText(product.description)
        heading.text = "Update Product"
        updateProductButton.text ="Update Product"
        Picasso.get().load(product.image).into(dialogImageView)


        updateProductButton.setOnClickListener {
            progressBarDialog.visibility = View.VISIBLE
            val newTitle = titleEditText.text.toString()
            val newDescription = descriptionEditText.text.toString()
            updateProduct(product._id!!, newTitle, newDescription, dialog)
        }

        dialog.show()
    }

    private fun updateProduct(productId: String, title: String, description: String, dialog: AlertDialog) {
        if (!::file.isInitialized) {
            Toast.makeText(requireContext(),"Please select an image",Toast.LENGTH_LONG).show()
            progressBarDialog.visibility =View.GONE
            return
        }

        val titlePart = FileUploadHelper.createPartFromString(title)
        val idPart = FileUploadHelper.createPartFromString(productId)
        val descriptionPart = FileUploadHelper.createPartFromString(description)
        val profilePicPart = file.createMultipartFile("image")

        if (profilePicPart != null) {
            val retrofit = BuilderServices.createService(ApiInterface::class.java)
            retrofit.updateProduct(token, idPart, titlePart, descriptionPart, profilePicPart).enqueue(object : Callback<CreateProductResponse> {
                override fun onResponse(call: Call<CreateProductResponse>, response: Response<CreateProductResponse>) {
                    if (response.isSuccessful) {
                        Toast.makeText(requireContext(),"Product updated successfully",Toast.LENGTH_LONG).show()
                        dialog.dismiss()
                        displayProductList(token)
                    } else {
                        Toast.makeText(requireContext(),"API call not successful: ${response.errorBody()?.string()}",Toast.LENGTH_LONG).show()
                    }
                }
                override fun onFailure(call: Call<CreateProductResponse>, t: Throwable) {
                    Toast.makeText(requireContext(),"API call failed: ${t.message}",Toast.LENGTH_LONG).show()
                }
            })
        }
    }

    private val pickMedia = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        handleMediaPickResult(uri)
    }

    private fun handleMediaPickResult(uri: Uri?) {
        if (uri != null) {
            Toast.makeText(requireContext(),"Image selected: $uri",Toast.LENGTH_LONG).show()
            file = FileUploadHelper.copyUriToInternalPath(requireContext(), uri) ?: return
            displaySelectedFile(file)
            Log.d("File Extension", "${file.extension}")
        } else {
            Toast.makeText(requireContext(),"Image not selected",Toast.LENGTH_LONG).show()
        }
    }

    private fun displaySelectedFile(file: File) {
        dialogImageView.visibility = View.VISIBLE
        Picasso.get().load(file).into(dialogImageView)
    }

    override fun onDeleteProduct(product: Datalist) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Product")
            .setMessage("Are you sure you want to delete this product?")
            .setPositiveButton("Yes") { dialog, _ ->
                deleteProduct(product._id!!)
                dialog.dismiss()
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun deleteProduct(productId: String) {
        val idPart = FileUploadHelper.createPartFromString(productId)
        val retrofit = BuilderServices.createService(ApiInterface::class.java)
        retrofit.deleteProduct(token, idPart).enqueue(object : Callback<CreateProductResponse> {
            override fun onResponse(call: Call<CreateProductResponse>, response: Response<CreateProductResponse>) {
                if (response.isSuccessful) {
                    Toast.makeText(requireContext(),"Product deleted successfully",Toast.LENGTH_LONG).show()
                    displayProductList(token)
                } else {
                    Toast.makeText(requireContext(),"API call not successful: ${response.errorBody()?.string()}",Toast.LENGTH_LONG).show()
                }
            }
            override fun onFailure(call: Call<CreateProductResponse>, t: Throwable) {
                Toast.makeText(requireContext(),"API call failed: ${t.message}",Toast.LENGTH_LONG).show()
            }
        })
    }
}
