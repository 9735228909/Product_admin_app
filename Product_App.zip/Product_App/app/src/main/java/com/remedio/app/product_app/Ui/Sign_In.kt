package com.remedio.app.product_app.Ui

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.remedio.app.product_app.ApiCalling.ApiInterface
import com.remedio.app.product_app.ApiCalling.BuilderServices
import com.remedio.app.product_app.Model.Sign_in_list
import com.remedio.app.product_app.Model.Signin_Request
import com.remedio.app.product_app.databinding.ActivitySignInBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Sign_In : AppCompatActivity() {
    private lateinit var binding: ActivitySignInBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)


        sharedPreferences = getSharedPreferences("signInResponse", MODE_PRIVATE)

        val email = intent.getStringExtra("email") ?: ""
        val password = intent.getStringExtra("password") ?: ""

        binding.edtemail.setText(email)
        binding.edtpassword.setText(password)

        binding.signInButton.setOnClickListener {
            val email = binding.edtemail.text.toString().trim()
            val password = binding.edtpassword.text.toString().trim()

            if (validate(email, password)) {
                apicalling(email, password)
            } else {
                Toast.makeText(this, "Please enter your details", Toast.LENGTH_LONG).show()
            }
        }

        binding.signupTV.setOnClickListener {
            val intent = Intent(this, Sign_Up::class.java)
            startActivity(intent)
            
        }
    }

    private fun apicalling(email: String, password: String) {
        val model = Signin_Request(email, password)
        val retrofit = BuilderServices.createService(ApiInterface::class.java)
        retrofit.signin(model).enqueue(object : Callback<Sign_in_list> {
            override fun onResponse(call: Call<Sign_in_list>, response: Response<Sign_in_list>) {
                if (response.isSuccessful) {
                    val bodymessage = response.body()?.message
                    if (bodymessage == "Logged in successfully"){
                        val body = response.body()
                        if (body != null) {
                            saveToSharedPreferences(body)
                            val intent = Intent(this@Sign_In, ProductActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }
                    else {
                        Toast.makeText(this@Sign_In, "${bodymessage}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this@Sign_In, "Error: ${response.message()}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<Sign_in_list>, t: Throwable) {
                Toast.makeText(this@Sign_In, "Failure: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun saveToSharedPreferences(body: Sign_in_list) {
        val json = Gson().toJson(body)
        val editor = sharedPreferences.edit()
        editor.putString("user_data", json)
        editor.putBoolean("isLoggedIn", true)
        editor.apply()
    }

    private fun validate(email: String, password: String): Boolean {
        var isValid = true

        binding.edtemail.error = null
        binding.edtpassword.error = null

        if (email.isBlank()) {
            binding.edtemail.error = "Please enter your email address"
            isValid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.edtemail.error = "Please enter a valid email address"
            isValid = false
        }

        if (password.isBlank()) {
            binding.edtpassword.error = "Please enter your password"
            isValid = false
        } else if (password.length < 8) {
            binding.edtpassword.error = "Password must be at least 8 characters long"
            isValid = false
        }

        return isValid
    }
}
