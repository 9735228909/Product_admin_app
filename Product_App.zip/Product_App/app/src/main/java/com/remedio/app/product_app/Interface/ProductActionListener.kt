package com.remedio.app.product_app.Interface

import com.remedio.app.product_app.Model.Datalist

interface ProductActionListener {

    fun onEditProduct(product: Datalist)
    fun onDeleteProduct(product: Datalist)

}