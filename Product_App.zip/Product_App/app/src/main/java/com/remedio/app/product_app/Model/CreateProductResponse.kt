package com.remedio.app.product_app.Model

data class CreateProductResponse(
    val `data`: Dataremove,
    val message: String,
    val status: Int
)

data class Dataremove(
    val _id: String? = "",
    val createdAt: String? = "",
    val description: String? = "",
    val image: String? = "",
    val isDeleted: Boolean? = false,
    val status: String? = "",
    val title: String? = "",
    val updatedAt: String? = ""
)
