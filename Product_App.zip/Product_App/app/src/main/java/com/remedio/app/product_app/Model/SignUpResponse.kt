package com.remedio.app.product_app.Model

data class SignUpResponse(
    val `data`: DataSignUp,
    val message: String,
    val status: Int,
    val token: String
)

data class DataSignUp(
    val _id: String,
    val createdAt: String,
    val deviceToken: String,
    val deviceType: String,
    val email: String,
    val first_name: String,
    val isActive: Boolean,
    val last_name: String,
    val profile_pic: String,
    val register_type: String,
    val role: String,
    val role_data: RoleDataUp,
    val updatedAt: String
)

data class RoleDataUp(
    val _id: String,
    val desc: String,
    val role: String,
    val roleDisplayName: String
)