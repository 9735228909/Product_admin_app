package com.remedio.app.product_app.Model

data class Product_list(
    val currentPage: Int,
    val `data`: List<Datalist>,
    val message: String,
    val perPage: Int,
    val status: Int,
    val totalPages: Int,
    val totalRecords: Int
)

data class Datalist(
    val _id: String,
    val createdAt: String,
    val description: String,
    val image: String,
    val isDeleted: Boolean,
    val status: String,
    val title: String,
    val updatedAt: String,
    val user_id: String
)