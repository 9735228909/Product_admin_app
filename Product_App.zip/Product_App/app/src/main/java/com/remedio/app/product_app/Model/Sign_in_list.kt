package com.remedio.app.product_app.Model

data class Sign_in_list(
    val `data`: Data,
    val message: String,
    val status: Int,
    val token: String
)

data class Data(
    val _id: String,
    val createdAt: String,
    val deviceToken: String,
    val deviceType: String,
    val email: String,
    val first_name: String,
    val isActive: Boolean,
    val last_name: String,
    val profile_pic: String,
    val register_type: String,
    val role: String,
    val role_data: RoleData,
    val updatedAt: String
)

data class RoleData(
    val _id: String,
    val desc: String,
    val role: String,
    val roleDisplayName: String
)