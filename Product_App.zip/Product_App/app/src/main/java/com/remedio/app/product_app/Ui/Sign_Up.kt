package com.remedio.app.product_app.Ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.remedio.app.product_app.ApiCalling.ApiInterface
import com.remedio.app.product_app.ApiCalling.BuilderServices
import com.remedio.app.product_app.FileUploadHelper
import com.remedio.app.product_app.FileUploadHelper.createMultipartFile
import com.remedio.app.product_app.Model.SignUpResponse
import com.remedio.app.product_app.databinding.ActivitySignUpBinding
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class Sign_Up : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding
    private lateinit var file:File
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.signUpButton.setOnClickListener {
            val firstname = binding.edtfirstName.text.toString().trim()
            val lastname = binding.edtlastName.text.toString().trim()
            val email = binding.edtemail.text.toString().trim()
            val password = binding.edtpassword.text.toString().trim()


            if (validate(firstname,lastname,email, password)) {
                if (::file.isInitialized) {
                    apicalling(firstname,lastname,email,password)
                }
                else {
                    Toast.makeText(this, "Please select an image", Toast.LENGTH_LONG).show()
                }
            }
            else {
                Toast.makeText(this, "Please enter your details", Toast.LENGTH_LONG).show()
            }
        }

        binding.signin.setOnClickListener {
            val intent = Intent(this,Sign_In::class.java)
            startActivity(intent)
            finish()
        }

        binding.uploadPicture.setOnClickListener {
            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

    }

    private fun apicalling(
        firstname: String,
        lastname: String,
        edtemail: String,
        edtpassword: String
    ) {

        binding.progressBar.visibility = View.VISIBLE

        val first_name = FileUploadHelper.createPartFromString(firstname)
        val last_name = FileUploadHelper.createPartFromString(lastname)
        val email = FileUploadHelper.createPartFromString(edtemail)
        val password = FileUploadHelper.createPartFromString(edtpassword)
        val profile_pic = file.createMultipartFile("image")

        val retrofit = BuilderServices.createService(ApiInterface::class.java)
        retrofit.signup(first_name,last_name,email,password,profile_pic).enqueue(object: Callback<SignUpResponse>{
            override fun onResponse(call: Call<SignUpResponse>, response: Response<SignUpResponse>) {
                binding.progressBar.visibility = View.GONE
                if (response.isSuccessful) {
                    val body = response.body()?.message
                    if (body == "Account created successfully") {
                        Toast.makeText(this@Sign_Up, "Registration Successful", Toast.LENGTH_LONG).show()
                        clearEditTexts()
                        val intent = Intent(this@Sign_Up, Sign_In::class.java)
                        intent.putExtra("email", edtemail)
                        intent.putExtra("password", edtpassword)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this@Sign_Up, " ${body}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this@Sign_Up, "Not success: ${response.errorBody()?.string()}", Toast.LENGTH_LONG).show()

                }
            }
            override fun onFailure(p0: Call<SignUpResponse>, p1: Throwable) {
                Toast.makeText(this@Sign_Up,"Failed: ${p1.message}",Toast.LENGTH_LONG).show()
                binding.progressBar.visibility=View.GONE
            }
        })
    }

    private fun clearEditTexts(){
        binding.edtfirstName.text?.clear()
        binding.edtlastName.text?.clear()
        binding.edtemail.text?.clear()
        binding.edtpassword.text?.clear()
        binding.imageView.visibility = View.GONE
    }

    private fun displaySelectedFile(file: File) {
        binding.imageView.visibility = View.VISIBLE
        Picasso.get().load(file).into(binding.imageView)
    }

    private val pickMedia = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            Toast.makeText(this,"Image selected: $uri",Toast.LENGTH_LONG).show()
            file = FileUploadHelper.copyUriToInternalPath(this,uri) ?: return@registerForActivityResult
            Log.d("File Extension", "${file.extension}")
            displaySelectedFile(file)
        } else {
            Toast.makeText(this,"Image not selected",Toast.LENGTH_LONG).show()
        }
    }

    private fun validate(firstname: String, lastname: String, email: String, password: String): Boolean {

        var isValid = true

        binding.edtfirstName.error = null
        binding.edtlastName.error = null
        binding.edtemail.error = null
        binding.edtpassword.error = null

        val nameRegex = "^[a-zA-Z]+$".toRegex()

        if (firstname.isBlank()) {
            binding.edtfirstName.error = "Please enter your first name"
            isValid = false
        } else if (!firstname.matches(nameRegex)) {
            binding.edtfirstName.error = "First name can only contain letters"
            isValid = false
        }

        if (lastname.isBlank()) {
            binding.edtlastName.error = "Please enter your last name"
            isValid = false
        } else if (!lastname.matches(nameRegex)) {
            binding.edtlastName.error = "Last name can only contain letters"
            isValid = false
        }

        if (email.isBlank()) {
            binding.edtemail.error = "Please enter your email address"
            isValid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.edtemail.error = "Please enter a valid email address"
            isValid = false
        }

        if (password.isBlank()) {
            binding.edtpassword.error = "Please enter your password"
            isValid = false
        } else if (password.length < 8) {
            binding.edtpassword.error = "Password must be at least 8 characters long"
            isValid = false
        }

        return isValid
    }
}